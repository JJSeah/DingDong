package com.example.jeremyjohn.dingdong;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.jeremyjohn.dingdong.models.Favourites;

import static com.google.android.gms.plus.PlusOneDummyView.TAG;

public class DBHelper extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 3;
    public static final String DATABASE_NAME = "DinDong.db";
    public static final String TABLE_FAV = "fav";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_DESNAME = "desname";
    public static final String COLUMN_DESNO = "desno";
    public static final String COLUMN_DESLAT = "deslat";
    public static final String COLUMN_DESLONG = "deslong";
    public static final String COLUMN_CURNAME = "curname";
    public static final String COLUMN_CURNO = "curno";
    public static final String COLUMN_CURLAT = "curlat";
    public static final String COLUMN_CURLONG = "curlong";

    public DBHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, DATABASE_NAME, factory, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_FAV
                + " (" + COLUMN_ID + " INTEGER PRIMARY KEY, "
                + COLUMN_DESNAME + " TEXT, "
                + COLUMN_DESNO + " TEXT, "
                + COLUMN_CURNAME + " TEXT, "
                + COLUMN_CURNO + " TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_FAV);
        onCreate(db);
    }

    public void addFav(String a,String b,String c,String d) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_DESNAME, a);
        values.put(COLUMN_DESNO, b);
        values.put(COLUMN_CURNAME, c);
        values.put(COLUMN_CURNO, d);
        SQLiteDatabase db = this.getWritableDatabase();
        db.insert(TABLE_FAV, null, values);
        Log.d(TAG,"PLEASEWORK" + c);
        db.close();
    }

    public boolean deleteFav(String desname, String curname) {
        SQLiteDatabase db = this.getWritableDatabase();
        Log.d(TAG,"DELTEPLEASE"+desname + curname);
        return db.delete(TABLE_FAV, COLUMN_DESNAME  + " = ? AND " + COLUMN_CURNAME + " = ?" , new String[]{desname,curname} ) != 0;
    }
    public Cursor getData(){
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT * FROM " + TABLE_FAV;
        Cursor data = db.rawQuery(query, null);

        return data;
    }

}
